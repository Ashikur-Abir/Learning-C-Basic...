// Write a program in C to read any digit and display in the word.
#include <stdio.h>
int main()
{
    int number;
    printf("Enter a digit between 0-9 ");
    scanf("%d", &number);

    switch (number)
    {
    case 0:
        printf("ZERO");
        break;
    case 1:
        printf("ONE");
        break;
    case 2:
        printf("TWO");
        break;
    case 3:
        printf("THREE");
        break;
    case 4:
        printf("FOUR");
        break;
    case 5:
        printf("FIVE");
        break;
    case 6:
        printf("SIX");
        break;
    case 7:
        printf("SEVEN");
        break;
    case 8:
        printf("EIGHT");
        break;
    case 9:
        printf("NINE");
        break;

    default:
        printf("Please enter a number between 0-9!");
    }

    return 0;
}