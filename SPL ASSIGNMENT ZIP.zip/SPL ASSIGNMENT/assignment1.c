// Write a program to input a whole sentence from the keyword as a string using scanf() funcation.

#include <stdio.h>
int main()
{
    char sen[100];
    printf("Enter ");
    gets(sen);
    printf("%s", sen);

    return 0;
}