/* Write a C program that checks if Y is greater than X and Z is greater than Y, given three integers X,Y and Z.
If both condition are true, the program return true.Othewise, it return false. */

#include <stdio.h>
int main()
{
    int X, Y, Z;
    printf("Enter the value of X,Y,Z: \n");
    scanf("%d %d %d", &X, &Y, &Z);

    if (X < Y && Y < Z)
    {
        printf("TRUE");
    }
    else
    {
        printf("FALSE");
    }

    return 0;
}