// Write a C program to swap two numbers using three methods(01).
#include <stdio.h>
int main()
{
    int a, b, temp;
    printf("a & b values ");
    scanf("%d %d", &a, &b);
    printf("Values before swapping; a=%d,b=%d\n", a, b);
    temp = a;
    a = b;
    b = temp;
    printf("Values after swapping; a=%d,b=%d", a, b);

    return 0;
}
