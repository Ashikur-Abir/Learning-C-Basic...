// Write a C program to check whether a character is an Alphabet,Digit or Special character

#include <stdio.h>
int main()
{
    char var;
    printf("Please enter the variable: ");
    scanf("%c", &var);

    if (var >= 65 && var <= 90 || var >= 97 && var <= 122)
    {
        printf("%c is a Alphabet", var);
    }
    else if (var >= 48 && var <= 57)
    {
        printf("%c is a Digit", var);
    }
    else if (var >= 0 && var <= 47 || var >= 58 && var <= 64 || var >= 91 && var <= 96 || var >= 123 && var <= 127)
    {
        printf("%c is a Special Symbol", var);
    }

    return 0;
}