// Write a C programe to find whether a given year is a leap year or not.
#include <stdio.h>
int main()
{
    int Year;
    printf("Please enter the Year: ");
    scanf("%d", &Year);

    if ((Year % 100 != 0 && Year % 4 == 0) ||
        (Year % 100 == 0 && Year % 400 == 0))
    {
        printf("%d is a Leap Year", Year);
    }
    else
    {
        printf("%d is Not Leap a Year", Year);
    }

    return 0;
}