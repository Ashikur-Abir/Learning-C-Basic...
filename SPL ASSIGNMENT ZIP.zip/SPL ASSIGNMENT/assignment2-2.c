// Write a C program to swap two numbers using three methods(02).
#include <stdio.h>
int main()
{
    int a, b;
    printf("a & b values ");
    scanf("%d %d", &a, &b);
    printf("Values before swapping; a=%d,b=%d\n", a, b);

    a = a + b;
    b = a - b;
    a = a - b;
    printf("Values after swapping; a=%d,b=%d", a, b);

    return 0;
}
