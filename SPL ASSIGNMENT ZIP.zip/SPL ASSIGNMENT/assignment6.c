// Write a C program to accept a coordinate point in an XY coordinate system and determine in which quandrant the coordinate point lies.
#include <stdio.h>
int main()
{
    int x, y;
    printf("Enter the value of X & Y\n");
    scanf("%d %d", &x, &y);

    if (x > 0 && y > 0)
    {
        printf("1st Quandrant");
    }
    else if (x < 0 && y > 0)
    {
        printf("2nd Quandrant");
    }
    else if (x < 0 && y < 0)
    {
        printf("3rd Quandrant");
    }
    else if (x > 0 && y < 0)
    {
        printf("4th Quandrant");
    }
    else
    {
        printf("Orgin Line");
    }

    return 0;
}